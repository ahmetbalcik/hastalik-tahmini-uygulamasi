## Değişiklik Açıklaması

Lütfen yaptığınız değişiklikleri aşağıda açıklayın:

### Yapılan Değişiklikler
- [Açıklama]

### Çözülen Sorunlar
- [Eğer bir GitHub sorunu varsa, ilgili sorun numarasını ekleyin]

### Ek Bilgiler
[Eğer başka önemli bir bilgi varsa ekleyin]

## Kontrol Listesi

- [ ] Kod, PEP 8 uyumlu mu?
- [ ] Yeni eklenen/çıkarılan kütüphaneler ve bağımlılıklar README.md dosyasında güncellendi mi?
- [ ] Yeni özellik veya değişiklikler için gerekli testler eklenmiş mi?

## Ekran Görüntüleri
[Eğer mümkünse, değişiklikleri göstermek için ekran görüntüleri ekleyin]

## Diğer Bilgiler
[Eğer başka önemli bir bilgi varsa ekleyin]

