## Sorun Açıklaması

Lütfen aşağıdaki bilgileri doldurunuz:

### Beklenen Davranış
[Beklenen davranışı açıklayın]

### Gerçekleşen Davranış
[Gerçekleşen davranışı açıklayın]

### Adımlar
[Problemle karşılaştığınızda adım adım nasıl reproduke edilebileceğini açıklayın]

## Ek Bilgiler

- Kullanılan İşletim Sistemi: [örneğin: Windows 10, Ubuntu 20.04]
- Kullanılan Python Sürümü: [örneğin: Python 3.8.5]
- Kullandığınız Uygulama Sürümü: [örneğin: v1.0.0]

## Ekran Görüntüleri
[Eğer mümkünse, sorunu açıklamak için ekran görüntüleri ekleyin]

## Diğer Bilgiler
[Eğer başka önemli bir bilgi varsa ekleyin]

